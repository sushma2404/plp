package com.bwa.ui;

import java.util.Scanner;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.LocalTime;

import com.bwa.bean.Bank;
import com.bwa.bean.Transaction;
import com.bwa.exception.BankUserInputException;
import com.bwa.service.BankWalletServiceImpl;
import com.bwa.service.IBankWalletService;
import com.bwa.validation.BankUserIOValidation;

public class ClientBUI {

	public static void main(String args[]) {
		Bank bank;
		Transaction transaction = new Transaction();
		BankUserIOValidation validation = new BankUserIOValidation();
		IBankWalletService bankWalletService = new BankWalletServiceImpl();
		Scanner scanner = new Scanner(System.in);
		int choice;
		LocalDate date = LocalDate.now();
		LocalTime time = LocalTime.now();
		while (true) {
			System.out.println("Welcome to xyz bank wallet");
			System.out.println("Choose any of these options from one to seven");
			System.out.println("1.Create an Account");
			System.out.println("2.Check your Balance");
			System.out.println("3.Deposit Money");
			System.out.println("4.Withdraw Money");
			System.out.println("5.Transfer Money");
			System.out.println("6.View Transaction");
			System.out.println("7.Exit");
			choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.println("ENTER YOUR NAME:");
				String name = scanner.next();
				try {
					while (!validation.checkName(name)) {
						System.out.print("    Enter your name : ");
						name = scanner.next();
						name += scanner.nextLine();
					}
				} catch (BankUserInputException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("ENTER YOUR DATE OF BIRTH IN DD/MM/YYYY");
				String dob = scanner.next();
				System.out.println("ENTER YOUR PHONE NUMBER ( MUST CONTAIN ONLY TEN DIGITS )");
				String phno = scanner.next();
				try {
					while (!validation.checkPhoneNumber(phno)) {
						System.out.print("Enter your phone number : ");
						phno = scanner.next();
					}
				} catch (BankUserInputException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("ENTER YOUR PIN(ONLY FOUR DIGITS)");
				int pin = scanner.nextInt();
				try {
					while (!validation.checkPIN(pin)) {
						System.out.print("Enter your PIN : ");
						pin = scanner.nextInt();
					}
				} catch (BankUserInputException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("ENTER THE AMOUNT YOU WANT TO DEPOSIT");
				long amt = scanner.nextLong();
				int acno = (int) ((Math.random()) * 1000000000);
				int tranid = (int) ((Math.random()) * 100000);
				bank = new Bank(acno, name, dob, phno, pin, amt);
				transaction = new Transaction(tranid, acno, "Account Created. Date : " + date + " Time : " + time
						+ " Rs." + amt + " was deposited successfully.");
				bankWalletService.addAccount(bank, transaction);
				System.out.println("Your account creteed.\n Your Account number is " + acno);
				break;
			case 2:
				System.out.println("ENTER YOUR ACCOUNT NUMBER : ");
				int accountNumber = scanner.nextInt();
				try {
					while (!validation.checkAccNo(accountNumber)) {
						System.out.print("Enter correct Account Number: ");
						accountNumber = scanner.nextInt();
					}
				} catch (BankUserInputException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				String message = bankWalletService.checkBalance(accountNumber);
				System.out.println(message);
				break;
			case 3:
				System.out.println("ENTER YOUR ACCOUNT NUMBER : ");
				int accountNumber1 = scanner.nextInt();
				try {
					while (!validation.checkAccNo(accountNumber1)) {
						System.out.print("Enter correct Account Number: ");
						accountNumber1 = scanner.nextInt();
					}
				} catch (BankUserInputException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.out.println("ENTER THE AMOUNT YOU NEED TO DEPOSIT : ");
				long amount = scanner.nextLong();
				int tranidd = (int) ((Math.random()) * 100000);
				transaction = new Transaction(tranidd, accountNumber1, "Ammount Deposited. Date : " + date + " Time : "
						+ time + " Rs." + amount + " was deposited successfully.");
				String message1 = bankWalletService.depositMoney(accountNumber1, amount, transaction);
				System.out.println(message1);
				break;
			case 4:
				System.out.println("ENTER YOUR ACCOUNT NUMBER : ");
				int accountNumberr = scanner.nextInt();
				try {
					while (!validation.checkAccNo(accountNumberr)) {
						System.out.print("Enter correct Account Number: ");
						accountNumberr = scanner.nextInt();
					}
				} catch (BankUserInputException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("ENTER THE AMOUNT YOU NEED TO WITHDRAW : ");
				long amountt = scanner.nextLong();
				int tranId = (int) ((Math.random()) * 100000);
				transaction = new Transaction(tranId, accountNumberr, "Ammount Withdrawn. Date : " + date + " Time : "
						+ time + " Rs." + amountt + " was withdrawn successfully.");
				String messagee = bankWalletService.withdrawMoney(accountNumberr, amountt, transaction);
				System.out.println(messagee);
				break;
			case 5:
				System.out.println("ENTER YOUR ACCOUNT NUMBER : ");
				int accountNumber01 = scanner.nextInt();
				try {
					while (!validation.checkAccNo(accountNumber01)) {
						System.out.print("Enter correct Account Number: ");
						accountNumber01 = scanner.nextInt();
					}
				} catch (BankUserInputException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("ENTER THE AMOUNT YOU NEED TO Send : ");
				long amount01 = scanner.nextLong();
				System.out.println("ENTER ANOTHER ACCOUNT NUMBER : ");
				int accountNumber02 = scanner.nextInt();
				try {
					while (!validation.checkAccNo(accountNumber02)) {
						System.out.print("Enter correct Account Number: ");
						accountNumber02 = scanner.nextInt();
					}
				} catch (BankUserInputException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				int tranid1 = (int) ((Math.random()) * 100000);
				int tranid2 = (int) ((Math.random()) * 100000);
				Transaction trans1 = new Transaction(tranid1, accountNumber01, "Ammount Sent. Date : " + date
						+ " Time : " + time + " Rs." + amount01 + " was set to " + accountNumber02 + " successfully.");
				Transaction trans2 = new Transaction(tranid2, accountNumber02,
						"Ammount Recived. Date : " + date + " Time : " + time + " Rs." + amount01 + " was recived from "
								+ accountNumber02 + " successfully.");
				String messages = bankWalletService.transferMoney(accountNumber01, amount01, accountNumber02, trans1,
						trans2);
				System.out.println(messages);
				break;
			case 6:
				System.out.println("ENTER YOUR ACCOUNT NUMBER : ");
				int accountNumbers = scanner.nextInt();
				try {
					while (!validation.checkAccNo(accountNumbers)) {
						System.out.print("Enter correct Account Number: ");
						accountNumbers = scanner.nextInt();
					}
				} catch (BankUserInputException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println(bankWalletService.getTransactionDetails(accountNumbers));
				break;
			case 7:
				System.out.println("Thank You for using our bank");
				scanner.close();
				break;
			default:
				System.out.println("You Entered Invalid choice." + "\n" + " Enter Valid choice");

			}
		}

	}

}
